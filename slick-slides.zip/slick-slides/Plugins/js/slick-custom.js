$(document).ready(function(){
    $(".slick-slider").slick({
        dots: true,
        autoplay:true,
        autoplaySpeed:3000,
        arrows:true,
        /* responsive: [{
            breakpoint: 1024,
            settings: {git
              slidesToShow: 3,
              slidesToScroll: 3,
              infinite: true,
              dots: true
            }
          },
          {
            breakpoint: 600,
            settings: {
              slidesToShow: 3,
              slidesToScroll: 1
            }
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1
            }
          }
        ], */
    });

    $('.multiple-items').slick({
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 3,
        autoplay:true,
        autoplaySpeed:3000,
      });
    
});

$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    $('.multiple-items').slick('setPosition');
  })
